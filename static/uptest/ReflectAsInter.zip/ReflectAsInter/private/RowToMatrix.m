function [Is,Qs,ts,fs0] = RowToMatrix(V,I,Q,t,fs,fsg)
fsw = fsg/400;
load('FswTd20211222.mat')
if fsw<10001
    td = interp1(fsw1,tdelay1,fsw,'spline');
    tdot = round(1e-6*td/(1/fs));
    fl = 0.1;
elseif fsw>10001
    td = interp1(fsw2,tdelay2,fsw,'spline');
    tdot = round(1e-6*td/(1/fs));
    fl = 0.5;
end
%%
V = smooth(V,31);
k = find(V>fl);
ind = k(1+find(diff(k)>(0.5*0.6*0.1*fs/fsw)));
ind0 = ind-tdot; %ÿ�����ڵ���㣬��0.1V��ʼ
len = round(mean(diff(ind)));
lent = fs/fsw;

lf = 0.87;
len2 = round(len*lf); %ÿ�����ڵĳ��ȣ���2.9V����
%%
if abs(lent-len)<3
    for i = 1:length(ind0)-1
        Is(:,i) = I(ind0(i):ind0(i)+len2);
        Qs(:,i) = Q(ind0(i):ind0(i)+len2);
        ts(:,i) = t(ind0(i):ind0(i)+len2);
    end
else
    disp('The length of sweep interval is wrong. Please check the sampling rate of the waveform generator')
end
load('VCO20211206.mat');
load('nv20211206.mat')
n1 = linspace(1,(lf*400+1),(len2+1));
n0 = linspace(1,(lf*400+1),(lf*400+1));
Vs = interp1(n0,y(5:(5+lf*400)),n1,'Spline');
fs0 = interp1(V0,f0,double(Vs),'Spline');

%% ��0.2V~2.9V
[~,I] = min(abs(Vs-0.2));
Vs = Vs(I:end);
Is = Is(I:end,:);
Qs = Qs(I:end,:);
ts = ts(I:end,:);
fs0 = fs0(I:end);
end