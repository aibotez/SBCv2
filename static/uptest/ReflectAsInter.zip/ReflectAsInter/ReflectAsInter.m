%% �ܶȵ�ʱ����������ڹ����ܶ�
clear
close all
load('220111006_refl.mat')
I = ReflI;
Q = ReflQ;
V = ReflWave;
t = time;
fs = 1/(t(2)-t(1));
fsg = 4e6;
figure;plot(t,I,'.-');hold on;plot(t,Q,'.-')
xlabel('Time (s)');ylabel('V');legend('I','Q');
[P,fP] = pwelch(I,4096,2048,4096,fs);
P(fP<0.5e5) = 0*P(fP<0.5e5);
figure;plot(fP/1e6,P);xlabel('Frequency (MHz)');ylabel('power spectral density (PSD)');xlim([0 3])
figure;spectrogram(I,256*8,256,256*8,fs,'yaxis');ylim([0 3]);
%%
[Is,Qs,ts,fs0] = RowToMatrix(V,I,Q,t,fs,fsg);
S0 = Qs+1i*Is;
fsys= [0.8e6 0.96e6]; %����������ʱƵ��
[b,a] = butter(3,[fsys(1)/(fs/2),fsys(2)/(fs/2)]);
Sf = filtfilt(b,a,S0);
phase = unwrap(angle(Sf));
for i = 1:size(phase,1)
    phases(i,:) = smooth(phase(i,:),201);
    phases(i,:) = 0.5*(phases(i,:)-mean(phases(i,1800:end))); %0.5��������
    nel(i,:) = phases(i,:)/2.82e-15/(3e8/fs0(i)/1e9)/1e16; 
end
nelm = mean(nel);
figure;plot(ts(1,:),nelm,'color','k','linewidth',1)
xlabel('time (s)');ylabel('Nel(\times10^{16}m^{-2})');


